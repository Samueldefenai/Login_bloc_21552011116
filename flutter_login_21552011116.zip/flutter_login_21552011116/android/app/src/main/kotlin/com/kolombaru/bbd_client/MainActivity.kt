package com.kolombaru.bbd_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
