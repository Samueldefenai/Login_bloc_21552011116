class LoginErrorModel {
  bool status;
  String value;

  LoginErrorModel({this.status, this.value});
}